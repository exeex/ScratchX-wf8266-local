
import webbrowser
webbrowser.open("http://127.0.0.1:8000", new=0, autoraise=True)