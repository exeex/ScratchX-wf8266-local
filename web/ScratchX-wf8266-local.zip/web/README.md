# ScratchX
Scratch Extension Site
Original Project = https://github.com/LLK/scratchx

# 怎麼下載?
按右上角Clone or download
選download zip

# 如何使用?

下載並解壓縮後  
直接執行 `StartServer.bat`  
會自動開啟瀏覽器並進入頁面

_註:不要把開啟的命令提示字元關掉，那是網頁伺服器_

# 別的電腦可以連我們用StartServer.bat建立的網站嗎?

如果你開起來的網頁的網址為區網IP  
ex.192.168.x.x   
則所有在**同一個區網**下的電腦，都可以透過同樣的網址連線呦  

# 我怎麼連不到WF8266?

請先確定
1. 你的電腦
2. 用StartServer.bat開網頁伺服器的電腦
3. WF8266
這三者都連線到同一個WIFI

若還是有問題，請多試幾次
